package GUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Majorgui extends JFrame {
    private JTextField txtMajorID, txtMajorKH, txtMajorEN, txtFacultyID;
    private JTextArea textArea;
    private JButton btnSave, btnLoad;
    
    // Database connection details
    private static final String URL = "jdbc:mysql://localhost:3306/StudentDB";
    private static final String USER = "root"; // Change to your MySQL username
    private static final String PASSWORD = ""; // Change to your MySQL password

    public Majorgui() {
        setTitle("Major Management");
        setSize(400, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(6, 2, 5, 5));

        // GUI Components
        add(new JLabel("Major ID:"));
        txtMajorID = new JTextField();
        add(txtMajorID);

        add(new JLabel("Major KH:"));
        txtMajorKH = new JTextField();
        add(txtMajorKH);

        add(new JLabel("Major EN:"));
        txtMajorEN = new JTextField();
        add(txtMajorEN);

        add(new JLabel("Faculty ID:"));
        txtFacultyID = new JTextField();
        add(txtFacultyID);

        btnSave = new JButton("Save Major");
        btnLoad = new JButton("Load Majors");
        add(btnSave);
        add(btnLoad);

        textArea = new JTextArea(10, 30);
        add(new JScrollPane(textArea));

        // Button actions
        btnSave.addActionListener(e -> saveMajor());
        btnLoad.addActionListener(e -> loadMajors());

        setVisible(true);
    }

    // Save Major to Database
    private void saveMajor() {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String sql = "INSERT INTO TblMajor (MajorID, MajorKH, MajorEN, FacultyID) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, Integer.parseInt(txtMajorID.getText()));
            stmt.setString(2, txtMajorKH.getText());
            stmt.setString(3, txtMajorEN.getText());
            stmt.setInt(4, Integer.parseInt(txtFacultyID.getText()));
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Major saved successfully!");
        } catch (SQLException | NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    // Load Majors from Database
    private void loadMajors() {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String sql = "SELECT * FROM TblMajor";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            textArea.setText("MajorID | MajorKH | MajorEN | FacultyID\n");
            while (rs.next()) {
                textArea.append(rs.getInt("MajorID") + " | " +
                        rs.getString("MajorKH") + " | " +
                        rs.getString("MajorEN") + " | " +
                        rs.getInt("FacultyID") + "\n");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Majorgui::new);
    }
}
