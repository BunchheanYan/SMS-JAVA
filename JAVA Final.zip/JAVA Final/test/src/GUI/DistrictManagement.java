package GUI;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class DistrictManagement extends JFrame {
    private JTextField txtDistrictID, txtDistrictKH, txtDistrictEN;
    private JComboBox<String> cmbProvince;
    private JButton btnAdd, btnUpdate, btnDelete, btnRefresh;
    private JTable table;
    private DefaultTableModel model;

    private static final String URL = "jdbc:mysql://localhost:3306/StudentDB";
    private static final String USER = "root";  // Change based on your setup
    private static final String PASSWORD = "";  // Change based on your setup

    public DistrictManagement() {
        setTitle("District Management");
        setSize(700, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Top Panel for Input Fields
        JPanel panelTop = new JPanel(new GridLayout(4, 2, 10, 10));
        panelTop.setBorder(BorderFactory.createTitledBorder("District Information"));

        panelTop.add(new JLabel("District ID:"));
        txtDistrictID = new JTextField();
        panelTop.add(txtDistrictID);

        panelTop.add(new JLabel("District (KH):"));
        txtDistrictKH = new JTextField();
        panelTop.add(txtDistrictKH);

        panelTop.add(new JLabel("District (EN):"));
        txtDistrictEN = new JTextField();
        panelTop.add(txtDistrictEN);

        panelTop.add(new JLabel("Province:"));
        cmbProvince = new JComboBox<>();
        panelTop.add(cmbProvince);

        add(panelTop, BorderLayout.NORTH);

        // Center Panel for Table
        model = new DefaultTableModel(new String[]{"District ID", "District KH", "District EN", "Province"}, 0);
        table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // Bottom Panel for Buttons
        JPanel panelBottom = new JPanel();
        btnAdd = new JButton("Add");
        btnUpdate = new JButton("Update");
        btnDelete = new JButton("Delete");
        btnRefresh = new JButton("Refresh");

        panelBottom.add(btnAdd);
        panelBottom.add(btnUpdate);
        panelBottom.add(btnDelete);
        panelBottom.add(btnRefresh);

        add(panelBottom, BorderLayout.SOUTH);

        // Load Data
        loadProvinces();
        loadData();

        // Button Listeners
        btnAdd.addActionListener(e -> insertData());
        btnUpdate.addActionListener(e -> updateData());
        btnDelete.addActionListener(e -> deleteData());
        btnRefresh.addActionListener(e -> loadData());

        // Table Row Selection Listener
        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int row = table.getSelectedRow();
                txtDistrictID.setText(model.getValueAt(row, 0).toString());
                txtDistrictKH.setText(model.getValueAt(row, 1).toString());
                txtDistrictEN.setText(model.getValueAt(row, 2).toString());
                cmbProvince.setSelectedItem(model.getValueAt(row, 3).toString());
            }
        });

        setVisible(true);
    }

    // Load Provinces into ComboBox
    private void loadProvinces() {
        cmbProvince.removeAllItems();
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT ProvinceID, ProvinceEN FROM TblProvince")) {
            while (rs.next()) {
                cmbProvince.addItem(rs.getInt("ProvinceID") + " - " + rs.getString("ProvinceEN"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Load Data from MySQL
    private void loadData() {
        model.setRowCount(0);
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT d.DistrictID, d.DistrictKH, d.DistrictEN, p.ProvinceEN FROM TblDistrict d JOIN TblProvince p ON d.ProvinceID = p.ProvinceID")) {
            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("DistrictID"),
                        rs.getString("DistrictKH"),
                        rs.getString("DistrictEN"),
                        rs.getString("ProvinceEN")
                });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Insert Data
    private void insertData() {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pst = conn.prepareStatement("INSERT INTO TblDistrict VALUES (?, ?, ?, ?)")) {
            pst.setInt(1, Integer.parseInt(txtDistrictID.getText()));
            pst.setString(2, txtDistrictKH.getText());
            pst.setString(3, txtDistrictEN.getText());
            pst.setInt(4, getSelectedProvinceID());
            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "Record Added!");
            loadData();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Update Data
    private void updateData() {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pst = conn.prepareStatement("UPDATE TblDistrict SET DistrictKH=?, DistrictEN=?, ProvinceID=? WHERE DistrictID=?")) {
            pst.setString(1, txtDistrictKH.getText());
            pst.setString(2, txtDistrictEN.getText());
            pst.setInt(3, getSelectedProvinceID());
            pst.setInt(4, Integer.parseInt(txtDistrictID.getText()));
            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "Record Updated!");
            loadData();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Delete Data
    private void deleteData() {
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete?", "Delete", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
                 PreparedStatement pst = conn.prepareStatement("DELETE FROM TblDistrict WHERE DistrictID=?")) {
                pst.setInt(1, Integer.parseInt(txtDistrictID.getText()));
                pst.executeUpdate();
                JOptionPane.showMessageDialog(this, "Record Deleted!");
                loadData();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    // Extract ProvinceID from ComboBox Selection
    private int getSelectedProvinceID() {
        String selectedItem = (String) cmbProvince.getSelectedItem();
        return Integer.parseInt(selectedItem.split(" - ")[0]);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(DistrictManagement::new);
    }
}
