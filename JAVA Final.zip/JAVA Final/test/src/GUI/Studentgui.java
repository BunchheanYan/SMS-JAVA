package GUI;


import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Studentgui extends JFrame {
    private JTextField txtStudentID, txtPassword, txtStudentNameKH, txtStudentNameEN, txtGenderID, txtDOB, txtDegreeID, txtMajorID, txtNationalityID;
    private JTextField txtFatherName, txtMotherName, txtFMContact, txtPhoneNumber, txtEmail, txtPhoto;
    private JButton btnAdd, btnUpdate, btnDelete, btnRefresh;
    private JTable table;
    private DefaultTableModel model;

    private static final String URL = "jdbc:mysql://localhost:3306/StudentDB";
    private static final String USER = "root";  // Change based on your setup
    private static final String PASSWORD = "";  // Change based on your setup

    public Studentgui() {
        setTitle("Student Management");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Top Panel for Input Fields
        JPanel panelTop = new JPanel(new GridLayout(14, 2, 10, 10));
        panelTop.setBorder(BorderFactory.createTitledBorder("Student Information"));

        panelTop.add(new JLabel("Student ID:"));
        txtStudentID = new JTextField();
        panelTop.add(txtStudentID);

        panelTop.add(new JLabel("Password:"));
        txtPassword = new JTextField();
        panelTop.add(txtPassword);

        panelTop.add(new JLabel("Student Name (KH):"));
        txtStudentNameKH = new JTextField();
        panelTop.add(txtStudentNameKH);

        panelTop.add(new JLabel("Student Name (EN):"));
        txtStudentNameEN = new JTextField();
        panelTop.add(txtStudentNameEN);

        panelTop.add(new JLabel("Gender ID:"));
        txtGenderID = new JTextField();
        panelTop.add(txtGenderID);

        panelTop.add(new JLabel("DOB:"));
        txtDOB = new JTextField();
        panelTop.add(txtDOB);

        panelTop.add(new JLabel("Degree ID:"));
        txtDegreeID = new JTextField();
        panelTop.add(txtDegreeID);

        panelTop.add(new JLabel("Major ID:"));
        txtMajorID = new JTextField();
        panelTop.add(txtMajorID);

        panelTop.add(new JLabel("Nationality ID:"));
        txtNationalityID = new JTextField();
        panelTop.add(txtNationalityID);

        panelTop.add(new JLabel("Father's Name:"));
        txtFatherName = new JTextField();
        panelTop.add(txtFatherName);

        panelTop.add(new JLabel("Mother's Name:"));
        txtMotherName = new JTextField();
        panelTop.add(txtMotherName);

        panelTop.add(new JLabel("FM Contact:"));
        txtFMContact = new JTextField();
        panelTop.add(txtFMContact);

        panelTop.add(new JLabel("Phone Number:"));
        txtPhoneNumber = new JTextField();
        panelTop.add(txtPhoneNumber);

        panelTop.add(new JLabel("Email:"));
        txtEmail = new JTextField();
        panelTop.add(txtEmail);

        panelTop.add(new JLabel("Photo:"));
        txtPhoto = new JTextField();
        panelTop.add(txtPhoto);

        add(panelTop, BorderLayout.NORTH);

        // Center Panel for Table
        model = new DefaultTableModel(new String[]{"Student ID", "Password", "Student Name KH", "Student Name EN", "Gender ID", "DOB", "Degree ID", "Major ID", "Nationality ID", "Father's Name", "Mother's Name", "FM Contact", "Phone Number", "Email", "Photo", "Register Date"}, 0);
        table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // Bottom Panel for Buttons
        JPanel panelBottom = new JPanel();
        btnAdd = new JButton("Add");
        btnUpdate = new JButton("Update");
        btnDelete = new JButton("Delete");
        btnRefresh = new JButton("Refresh");

        panelBottom.add(btnAdd);
        panelBottom.add(btnUpdate);
        panelBottom.add(btnDelete);
        panelBottom.add(btnRefresh);

        add(panelBottom, BorderLayout.SOUTH);

        // Load Data
        loadData();

        // Button Listeners
        btnAdd.addActionListener(e -> insertData());
        btnUpdate.addActionListener(e -> updateData());
        btnDelete.addActionListener(e -> deleteData());
        btnRefresh.addActionListener(e -> loadData());

        // Table Row Selection Listener
        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int row = table.getSelectedRow();
                txtStudentID.setText(model.getValueAt(row, 0).toString());
                txtPassword.setText(model.getValueAt(row, 1).toString());
                txtStudentNameKH.setText(model.getValueAt(row, 2).toString());
                txtStudentNameEN.setText(model.getValueAt(row, 3).toString());
                txtGenderID.setText(model.getValueAt(row, 4).toString());
                txtDOB.setText(model.getValueAt(row, 5).toString());
                txtDegreeID.setText(model.getValueAt(row, 6).toString());
                txtMajorID.setText(model.getValueAt(row, 7).toString());
                txtNationalityID.setText(model.getValueAt(row, 8).toString());
                txtFatherName.setText(model.getValueAt(row, 9).toString());
                txtMotherName.setText(model.getValueAt(row, 10).toString());
                txtFMContact.setText(model.getValueAt(row, 11).toString());
                txtPhoneNumber.setText(model.getValueAt(row, 12).toString());
                txtEmail.setText(model.getValueAt(row, 13).toString());
                txtPhoto.setText(model.getValueAt(row, 14).toString());
            }
        });

        setVisible(true);
    }

    // Load Data from MySQL
    private void loadData() {
        model.setRowCount(0);
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM TblStudent")) {
            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("StudentID"),
                        rs.getString("Password"),
                        rs.getString("StudentNameKH"),
                        rs.getString("StudentNameEN"),
                        rs.getInt("GenderID"),
                        rs.getDate("DOB"),
                        rs.getInt("DegreeID"),
                        rs.getInt("MajorID"),
                        rs.getInt("NationalityID"),
                        rs.getString("FatherName"),
                        rs.getString("MotherName"),
                        rs.getString("FMContact"),
                        rs.getString("PhoneNumber"),
                        rs.getString("Email"),
                        rs.getString("Photo"),
                        rs.getTimestamp("RegisterDate")
                });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Insert Data
    private void insertData() {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pst = conn.prepareStatement("INSERT INTO TblStudent VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")) {
            pst.setInt(1, Integer.parseInt(txtStudentID.getText()));
            pst.setString(2, txtPassword.getText());
            pst.setString(3, txtStudentNameKH.getText());
            pst.setString(4, txtStudentNameEN.getText());
            pst.setInt(5, Integer.parseInt(txtGenderID.getText()));
            pst.setDate(6, Date.valueOf(txtDOB.getText()));
            pst.setInt(7, Integer.parseInt(txtDegreeID.getText()));
            pst.setInt(8, Integer.parseInt(txtMajorID.getText()));
            pst.setInt(9, Integer.parseInt(txtNationalityID.getText()));
            pst.setString(10, txtFatherName.getText());
            pst.setString(11, txtMotherName.getText());
            pst.setString(12, txtFMContact.getText());
            pst.setString(13, txtPhoneNumber.getText());
            pst.setString(14, txtEmail.getText());
            pst.setString(15, txtPhoto.getText());
            pst.setTimestamp(16, new Timestamp(System.currentTimeMillis()));
            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "Record Added!");
            loadData();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Update Data
    private void updateData() {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pst = conn.prepareStatement("UPDATE TblStudent SET Password=?, StudentNameKH=?, StudentNameEN=?, GenderID=?, DOB=?, DegreeID=?, MajorID=?, NationalityID=?, FatherName=?, MotherName=?, FMContact=?, PhoneNumber=?, Email=?, Photo=? WHERE StudentID=?")) {
            pst.setString(1, txtPassword.getText());
            pst.setString(2, txtStudentNameKH.getText());
            pst.setString(3, txtStudentNameEN.getText());
            pst.setInt(4, Integer.parseInt(txtGenderID.getText()));
            pst.setDate(5, Date.valueOf(txtDOB.getText()));
            pst.setInt(6, Integer.parseInt(txtDegreeID.getText()));
            pst.setInt(7, Integer.parseInt(txtMajorID.getText()));
            pst.setInt(8, Integer.parseInt(txtNationalityID.getText()));
            pst.setString(9, txtFatherName.getText());
            pst.setString(10, txtMotherName.getText());
            pst.setString(11, txtFMContact.getText());
            pst.setString(12, txtPhoneNumber.getText());
            pst.setString(13, txtEmail.getText());
            pst.setString(14, txtPhoto.getText());
            pst.setInt(15, Integer.parseInt(txtStudentID.getText()));
            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "Record Updated!");
            loadData();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Delete Data
    private void deleteData() {
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete?", "Delete", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
                 PreparedStatement pst = conn.prepareStatement("DELETE FROM TblStudent WHERE StudentID=?")) {
                pst.setInt(1, Integer.parseInt(txtStudentID.getText()));
                pst.executeUpdate();
                JOptionPane.showMessageDialog(this, "Record Deleted!");
                loadData();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Studentgui::new);
    }
}
