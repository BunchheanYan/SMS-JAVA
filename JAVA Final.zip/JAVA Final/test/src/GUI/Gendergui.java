package GUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Gendergui extends JFrame {
    private JTextField txtGenderID, txtGenderKH, txtGenderEN;
    private JButton btnSave, btnUpdate, btnDelete, btnLoad;
    private JTextArea textArea;
    
    // Database Connection Variables
    private static final String URL = "jdbc:mysql://localhost:3306/StudentDB";
    private static final String USER = "root"; // Change if necessary
    private static final String PASSWORD = ""; // Change if necessary

    public Gendergui() {
        setTitle("Gender Management");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        // GUI Components
        txtGenderID = new JTextField(10);
        txtGenderKH = new JTextField(15);
        txtGenderEN = new JTextField(15);
        btnSave = new JButton("Save");
        btnUpdate = new JButton("Update");
        btnDelete = new JButton("Delete");
        btnLoad = new JButton("Load Data");
        textArea = new JTextArea(10, 40);
        textArea.setEditable(false);
        
        // Add Components to Frame
        add(new JLabel("Gender ID:"));
        add(txtGenderID);
        add(new JLabel("Gender KH:"));
        add(txtGenderKH);
        add(new JLabel("Gender EN:"));
        add(txtGenderEN);
        add(btnSave);
        add(btnUpdate);
        add(btnDelete);
        add(btnLoad);
        add(new JScrollPane(textArea));

        // Button Actions
        btnSave.addActionListener(e -> insertGender());
        btnUpdate.addActionListener(e -> updateGender());
        btnDelete.addActionListener(e -> deleteGender());
        btnLoad.addActionListener(e -> loadGenderData());

        setVisible(true);
    }

    // 1️⃣ **Insert Gender Record**
    private void insertGender() {
        String query = "INSERT INTO TblGender (GenderID, GenderKH, GenderEN) VALUES (?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, Integer.parseInt(txtGenderID.getText()));
            stmt.setString(2, txtGenderKH.getText());
            stmt.setString(3, txtGenderEN.getText());
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Record Inserted!");
            loadGenderData();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    // 2️⃣ **Update Gender Record**
    private void updateGender() {
        String query = "UPDATE TblGender SET GenderKH = ?, GenderEN = ? WHERE GenderID = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setString(1, txtGenderKH.getText());
            stmt.setString(2, txtGenderEN.getText());
            stmt.setInt(3, Integer.parseInt(txtGenderID.getText()));
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Record Updated!");
            loadGenderData();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    // 3️⃣ **Delete Gender Record**
    private void deleteGender() {
        String query = "DELETE FROM TblGender WHERE GenderID = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, Integer.parseInt(txtGenderID.getText()));
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Record Deleted!");
            loadGenderData();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    // 4️⃣ **Load Gender Data**
    private void loadGenderData() {
        String query = "SELECT * FROM TblGender";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            textArea.setText("GenderID\tGenderKH\tGenderEN\n");
            while (rs.next()) {
                textArea.append(rs.getInt("GenderID") + "\t" + rs.getString("GenderKH") + "\t" + rs.getString("GenderEN") + "\n");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Gendergui::new);
    }
}
