package GUI;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class VillageManagement extends JFrame {
    private JTextField txtVillageID, txtVillageKH, txtVillageEN;
    private JComboBox<String> cmbCommune;
    private JButton btnAdd, btnUpdate, btnDelete, btnRefresh;
    private JTable table;
    private DefaultTableModel model;

    private static final String URL = "jdbc:mysql://localhost:3306/StudentDB";
    private static final String USER = "root";  // Change based on your setup
    private static final String PASSWORD = "";  // Change based on your setup

    public VillageManagement() {
        setTitle("Village Management");
        setSize(700, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Top Panel for Input Fields
        JPanel panelTop = new JPanel(new GridLayout(4, 2, 10, 10));
        panelTop.setBorder(BorderFactory.createTitledBorder("Village Information"));

        panelTop.add(new JLabel("Village ID:"));
        txtVillageID = new JTextField();
        panelTop.add(txtVillageID);

        panelTop.add(new JLabel("Village (KH):"));
        txtVillageKH = new JTextField();
        panelTop.add(txtVillageKH);

        panelTop.add(new JLabel("Village (EN):"));
        txtVillageEN = new JTextField();
        panelTop.add(txtVillageEN);

        panelTop.add(new JLabel("Commune:"));
        cmbCommune = new JComboBox<>();
        panelTop.add(cmbCommune);

        add(panelTop, BorderLayout.NORTH);

        // Center Panel for Table
        model = new DefaultTableModel(new String[]{"Village ID", "Village KH", "Village EN", "Commune"}, 0);
        table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // Bottom Panel for Buttons
        JPanel panelBottom = new JPanel();
        btnAdd = new JButton("Add");
        btnUpdate = new JButton("Update");
        btnDelete = new JButton("Delete");
        btnRefresh = new JButton("Refresh");

        panelBottom.add(btnAdd);
        panelBottom.add(btnUpdate);
        panelBottom.add(btnDelete);
        panelBottom.add(btnRefresh);

        add(panelBottom, BorderLayout.SOUTH);

        // Load Data
        loadCommuneData();
        loadData();

        // Button Listeners
        btnAdd.addActionListener(e -> insertData());
        btnUpdate.addActionListener(e -> updateData());
        btnDelete.addActionListener(e -> deleteData());
        btnRefresh.addActionListener(e -> loadData());

        // Table Row Selection Listener
        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int row = table.getSelectedRow();
                txtVillageID.setText(model.getValueAt(row, 0).toString());
                txtVillageKH.setText(model.getValueAt(row, 1).toString());
                txtVillageEN.setText(model.getValueAt(row, 2).toString());
                cmbCommune.setSelectedItem(model.getValueAt(row, 3).toString());
            }
        });

        setVisible(true);
    }

    // Load Commune Data into ComboBox
    private void loadCommuneData() {
        cmbCommune.removeAllItems();
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT CommuneID, CommuneEN FROM TblCommune")) {
            while (rs.next()) {
                cmbCommune.addItem(rs.getInt("CommuneID") + " - " + rs.getString("CommuneEN"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Load Data from MySQL
    private void loadData() {
        model.setRowCount(0);
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT v.VillageID, v.VillageKH, v.VillageEN, c.CommuneEN FROM TblVillage v JOIN TblCommune c ON v.CommuneID = c.CommuneID")) {
            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("VillageID"),
                        rs.getString("VillageKH"),
                        rs.getString("VillageEN"),
                        rs.getString("CommuneEN")
                });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Insert Data
    private void insertData() {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pst = conn.prepareStatement("INSERT INTO TblVillage VALUES (?, ?, ?, ?)")) {
            pst.setInt(1, Integer.parseInt(txtVillageID.getText()));
            pst.setString(2, txtVillageKH.getText());
            pst.setString(3, txtVillageEN.getText());
            pst.setInt(4, getSelectedCommuneID());
            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "Record Added!");
            loadData();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Update Data
    private void updateData() {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pst = conn.prepareStatement("UPDATE TblVillage SET VillageKH=?, VillageEN=?, CommuneID=? WHERE VillageID=?")) {
            pst.setString(1, txtVillageKH.getText());
            pst.setString(2, txtVillageEN.getText());
            pst.setInt(3, getSelectedCommuneID());
            pst.setInt(4, Integer.parseInt(txtVillageID.getText()));
            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "Record Updated!");
            loadData();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Delete Data
    private void deleteData() {
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete?", "Delete", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
                 PreparedStatement pst = conn.prepareStatement("DELETE FROM TblVillage WHERE VillageID=?")) {
                pst.setInt(1, Integer.parseInt(txtVillageID.getText()));
                pst.executeUpdate();
                JOptionPane.showMessageDialog(this, "Record Deleted!");
                loadData();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    // Extract CommuneID from ComboBox Selection
    private int getSelectedCommuneID() {
        String selectedItem = (String) cmbCommune.getSelectedItem();
        return Integer.parseInt(selectedItem.split(" - ")[0]);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(VillageManagement::new);
    }
}
