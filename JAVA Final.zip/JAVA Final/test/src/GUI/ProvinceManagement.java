package GUI;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class ProvinceManagement extends JFrame {
    private JTextField txtProvinceID, txtProvinceKH, txtProvinceEN;
    private JButton btnAdd, btnUpdate, btnDelete, btnRefresh;
    private JTable table;
    private DefaultTableModel model;

    // Database Connection Parameters
    private static final String URL = "jdbc:mysql://localhost:3306/StudentDB";
    private static final String USER = "root";  // Change as per your MySQL setup
    private static final String PASSWORD = "";  // Change as per your MySQL setup

    public ProvinceManagement() {
        setTitle("Province Management");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Top Panel for Input Fields
        JPanel panelTop = new JPanel(new GridLayout(3, 2, 10, 10));
        panelTop.setBorder(BorderFactory.createTitledBorder("Province Information"));

        panelTop.add(new JLabel("Province ID:"));
        txtProvinceID = new JTextField();
        panelTop.add(txtProvinceID);

        panelTop.add(new JLabel("Province (KH):"));
        txtProvinceKH = new JTextField();
        panelTop.add(txtProvinceKH);

        panelTop.add(new JLabel("Province (EN):"));
        txtProvinceEN = new JTextField();
        panelTop.add(txtProvinceEN);

        add(panelTop, BorderLayout.NORTH);

        // Center Panel for Table
        model = new DefaultTableModel(new String[]{"Province ID", "Province KH", "Province EN"}, 0);
        table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // Bottom Panel for Buttons
        JPanel panelBottom = new JPanel();
        btnAdd = new JButton("Add");
        btnUpdate = new JButton("Update");
        btnDelete = new JButton("Delete");
        btnRefresh = new JButton("Refresh");

        panelBottom.add(btnAdd);
        panelBottom.add(btnUpdate);
        panelBottom.add(btnDelete);
        panelBottom.add(btnRefresh);

        add(panelBottom, BorderLayout.SOUTH);

        // Load Data from Database
        loadData();

        // Button Listeners
        btnAdd.addActionListener(e -> insertData());
        btnUpdate.addActionListener(e -> updateData());
        btnDelete.addActionListener(e -> deleteData());
        btnRefresh.addActionListener(e -> loadData());

        // Table Row Selection Listener
        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int row = table.getSelectedRow();
                txtProvinceID.setText(model.getValueAt(row, 0).toString());
                txtProvinceKH.setText(model.getValueAt(row, 1).toString());
                txtProvinceEN.setText(model.getValueAt(row, 2).toString());
            }
        });

        setVisible(true);
    }

    // Load Data from MySQL
    private void loadData() {
        model.setRowCount(0);
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM TblProvince")) {
            while (rs.next()) {
                model.addRow(new Object[]{rs.getInt("ProvinceID"), rs.getString("ProvinceKH"), rs.getString("ProvinceEN")});
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Insert Data into Database
    private void insertData() {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pst = conn.prepareStatement("INSERT INTO TblProvince VALUES (?, ?, ?)")) {
            pst.setInt(1, Integer.parseInt(txtProvinceID.getText()));
            pst.setString(2, txtProvinceKH.getText());
            pst.setString(3, txtProvinceEN.getText());
            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "Record Added!");
            loadData();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Update Data in Database
    private void updateData() {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pst = conn.prepareStatement("UPDATE TblProvince SET ProvinceKH=?, ProvinceEN=? WHERE ProvinceID=?")) {
            pst.setString(1, txtProvinceKH.getText());
            pst.setString(2, txtProvinceEN.getText());
            pst.setInt(3, Integer.parseInt(txtProvinceID.getText()));
            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "Record Updated!");
            loadData();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Delete Data from Database
    private void deleteData() {
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete?", "Delete", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
                 PreparedStatement pst = conn.prepareStatement("DELETE FROM TblProvince WHERE ProvinceID=?")) {
                pst.setInt(1, Integer.parseInt(txtProvinceID.getText()));
                pst.executeUpdate();
                JOptionPane.showMessageDialog(this, "Record Deleted!");
                loadData();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ProvinceManagement::new);
    }
}
