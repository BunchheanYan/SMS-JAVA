package GUI;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class CommuneManagement extends JFrame {
    private JTextField txtCommuneID, txtCommuneKH, txtCommuneEN;
    private JComboBox<String> cmbDistrict;
    private JButton btnAdd, btnUpdate, btnDelete, btnRefresh;
    private JTable table;
    private DefaultTableModel model;

    private static final String URL = "jdbc:mysql://localhost:3306/StudentDB";
    private static final String USER = "root";  // Change based on your setup
    private static final String PASSWORD = "";  // Change based on your setup

    public CommuneManagement() {
        setTitle("Commune Management");
        setSize(700, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Top Panel for Input Fields
        JPanel panelTop = new JPanel(new GridLayout(4, 2, 10, 10));
        panelTop.setBorder(BorderFactory.createTitledBorder("Commune Information"));

        panelTop.add(new JLabel("Commune ID:"));
        txtCommuneID = new JTextField();
        panelTop.add(txtCommuneID);

        panelTop.add(new JLabel("Commune (KH):"));
        txtCommuneKH = new JTextField();
        panelTop.add(txtCommuneKH);

        panelTop.add(new JLabel("Commune (EN):"));
        txtCommuneEN = new JTextField();
        panelTop.add(txtCommuneEN);

        panelTop.add(new JLabel("District:"));
        cmbDistrict = new JComboBox<>();
        panelTop.add(cmbDistrict);

        add(panelTop, BorderLayout.NORTH);

        // Center Panel for Table
        model = new DefaultTableModel(new String[]{"Commune ID", "Commune KH", "Commune EN", "District"}, 0);
        table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // Bottom Panel for Buttons
        JPanel panelBottom = new JPanel();
        btnAdd = new JButton("Add");
        btnUpdate = new JButton("Update");
        btnDelete = new JButton("Delete");
        btnRefresh = new JButton("Refresh");

        panelBottom.add(btnAdd);
        panelBottom.add(btnUpdate);
        panelBottom.add(btnDelete);
        panelBottom.add(btnRefresh);

        add(panelBottom, BorderLayout.SOUTH);

        // Load Data
        loadDistricts();
        loadData();

        // Button Listeners
        btnAdd.addActionListener(e -> insertData());
        btnUpdate.addActionListener(e -> updateData());
        btnDelete.addActionListener(e -> deleteData());
        btnRefresh.addActionListener(e -> loadData());

        // Table Row Selection Listener
        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int row = table.getSelectedRow();
                txtCommuneID.setText(model.getValueAt(row, 0).toString());
                txtCommuneKH.setText(model.getValueAt(row, 1).toString());
                txtCommuneEN.setText(model.getValueAt(row, 2).toString());
                cmbDistrict.setSelectedItem(model.getValueAt(row, 3).toString());
            }
        });

        setVisible(true);
    }

    // Load Districts into ComboBox
    private void loadDistricts() {
        cmbDistrict.removeAllItems();
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT DistrictID, DistrictEN FROM TblDistrict")) {
            while (rs.next()) {
                cmbDistrict.addItem(rs.getInt("DistrictID") + " - " + rs.getString("DistrictEN"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Load Data from MySQL
    private void loadData() {
        model.setRowCount(0);
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT c.CommuneID, c.CommuneKH, c.CommuneEN, d.DistrictEN FROM TblCommune c JOIN TblDistrict d ON c.DistrictID = d.DistrictID")) {
            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("CommuneID"),
                        rs.getString("CommuneKH"),
                        rs.getString("CommuneEN"),
                        rs.getString("DistrictEN")
                });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Insert Data
    private void insertData() {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pst = conn.prepareStatement("INSERT INTO TblCommune VALUES (?, ?, ?, ?)")) {
            pst.setInt(1, Integer.parseInt(txtCommuneID.getText()));
            pst.setString(2, txtCommuneKH.getText());
            pst.setString(3, txtCommuneEN.getText());
            pst.setInt(4, getSelectedDistrictID());
            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "Record Added!");
            loadData();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Update Data
    private void updateData() {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pst = conn.prepareStatement("UPDATE TblCommune SET CommuneKH=?, CommuneEN=?, DistrictID=? WHERE CommuneID=?")) {
            pst.setString(1, txtCommuneKH.getText());
            pst.setString(2, txtCommuneEN.getText());
            pst.setInt(3, getSelectedDistrictID());
            pst.setInt(4, Integer.parseInt(txtCommuneID.getText()));
            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "Record Updated!");
            loadData();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Delete Data
    private void deleteData() {
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete?", "Delete", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
                 PreparedStatement pst = conn.prepareStatement("DELETE FROM TblCommune WHERE CommuneID=?")) {
                pst.setInt(1, Integer.parseInt(txtCommuneID.getText()));
                pst.executeUpdate();
                JOptionPane.showMessageDialog(this, "Record Deleted!");
                loadData();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    // Extract DistrictID from ComboBox Selection
    private int getSelectedDistrictID() {
        String selectedItem = (String) cmbDistrict.getSelectedItem();
        return Integer.parseInt(selectedItem.split(" - ")[0]);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(CommuneManagement::new);
    }
}
