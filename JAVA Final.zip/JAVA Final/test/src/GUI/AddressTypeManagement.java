package GUI;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class AddressTypeManagement extends JFrame {
    private JTextField txtAddressTypeID, txtAddressTypeKH, txtAddressTypeEN;
    private JButton btnAdd, btnUpdate, btnDelete, btnRefresh;
    private JTable table;
    private DefaultTableModel model;

    private static final String URL = "jdbc:mysql://localhost:3306/StudentDB";
    private static final String USER = "root";  // Change based on your setup
    private static final String PASSWORD = "";  // Change based on your setup

    public AddressTypeManagement() {
        setTitle("Address Type Management");
        setSize(700, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Top Panel for Input Fields
        JPanel panelTop = new JPanel(new GridLayout(4, 2, 10, 10));
        panelTop.setBorder(BorderFactory.createTitledBorder("Address Type Information"));

        panelTop.add(new JLabel("Address Type ID:"));
        txtAddressTypeID = new JTextField();
        panelTop.add(txtAddressTypeID);

        panelTop.add(new JLabel("Address Type (KH):"));
        txtAddressTypeKH = new JTextField();
        panelTop.add(txtAddressTypeKH);

        panelTop.add(new JLabel("Address Type (EN):"));
        txtAddressTypeEN = new JTextField();
        panelTop.add(txtAddressTypeEN);

        add(panelTop, BorderLayout.NORTH);

        // Center Panel for Table
        model = new DefaultTableModel(new String[]{"Address Type ID", "Address Type KH", "Address Type EN"}, 0);
        table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // Bottom Panel for Buttons
        JPanel panelBottom = new JPanel();
        btnAdd = new JButton("Add");
        btnUpdate = new JButton("Update");
        btnDelete = new JButton("Delete");
        btnRefresh = new JButton("Refresh");

        panelBottom.add(btnAdd);
        panelBottom.add(btnUpdate);
        panelBottom.add(btnDelete);
        panelBottom.add(btnRefresh);

        add(panelBottom, BorderLayout.SOUTH);

        // Load Data
        loadData();

        // Button Listeners
        btnAdd.addActionListener(e -> insertData());
        btnUpdate.addActionListener(e -> updateData());
        btnDelete.addActionListener(e -> deleteData());
        btnRefresh.addActionListener(e -> loadData());

        // Table Row Selection Listener
        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int row = table.getSelectedRow();
                txtAddressTypeID.setText(model.getValueAt(row, 0).toString());
                txtAddressTypeKH.setText(model.getValueAt(row, 1).toString());
                txtAddressTypeEN.setText(model.getValueAt(row, 2).toString());
            }
        });

        setVisible(true);
    }

    // Load Data from MySQL
    private void loadData() {
        model.setRowCount(0);
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT AddressTypeID, AddressTypeKH, AddressTypeEN FROM TblAddressType")) {
            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("AddressTypeID"),
                        rs.getString("AddressTypeKH"),
                        rs.getString("AddressTypeEN")
                });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Insert Data
    private void insertData() {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pst = conn.prepareStatement("INSERT INTO TblAddressType VALUES (?, ?, ?)")) {
            pst.setInt(1, Integer.parseInt(txtAddressTypeID.getText()));
            pst.setString(2, txtAddressTypeKH.getText());
            pst.setString(3, txtAddressTypeEN.getText());
            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "Record Added!");
            loadData();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Update Data
    private void updateData() {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pst = conn.prepareStatement("UPDATE TblAddressType SET AddressTypeKH=?, AddressTypeEN=? WHERE AddressTypeID=?")) {
            pst.setString(1, txtAddressTypeKH.getText());
            pst.setString(2, txtAddressTypeEN.getText());
            pst.setInt(3, Integer.parseInt(txtAddressTypeID.getText()));
            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "Record Updated!");
            loadData();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Delete Data
    private void deleteData() {
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete?", "Delete", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
                 PreparedStatement pst = conn.prepareStatement("DELETE FROM TblAddressType WHERE AddressTypeID=?")) {
                pst.setInt(1, Integer.parseInt(txtAddressTypeID.getText()));
                pst.executeUpdate();
                JOptionPane.showMessageDialog(this, "Record Deleted!");
                loadData();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(AddressTypeManagement::new);
    }
}
