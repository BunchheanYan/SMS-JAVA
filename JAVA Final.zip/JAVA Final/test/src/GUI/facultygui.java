package GUI;

import javax.swing.*;
import javax.swing.text.JTextComponent;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class facultygui extends JFrame {
    private JTextField txtFacultyKH, txtFacultyEN;
    private JButton btnSave, btnLoad;
    private JTextArea textArea;
	private JTextComponent txtAddressTypeID;
	private JTextComponent txtHomeNumber;
	private JTextComponent txtStreetNumber;
	private JTextComponent txtProvinceID;
	private JTextComponent txtDistrictID;
	private JTextComponent txtCommuneID;
	private JTextComponent txtVillageID;
	private JTextComponent txtStudentID;
    
    // Database connection details
    private static final String URL = "jdbc:mysql://localhost:3306/StudentDB";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    public facultygui() {
        setTitle("Faculty Management");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        // GUI Components
        txtFacultyKH = new JTextField(15);
        txtFacultyEN = new JTextField(15);
        btnSave = new JButton("Save");
        btnLoad = new JButton("Load Data");
        textArea = new JTextArea(10, 30);
        
        // Add components to frame
        add(new JLabel("Faculty Name KH:"));
        add(txtFacultyKH);
        add(new JLabel("Faculty Name EN:"));
        add(txtFacultyEN);
        add(btnSave);
        add(btnLoad);
        add(new JScrollPane(textArea));

        // Button Actions
        btnSave.addActionListener(e -> saveFaculty());
        btnLoad.addActionListener(e -> loadFaculty());

        setVisible(true);
    }

    private Object saveFaculty() {
		// TODO Auto-generated method stub
		return null;
	}

	private void saveAddress() {
        try {
            int addressID = Integer.parseInt(JOptionPane.showInputDialog("Enter Address ID:")); // Get AddressID from the user
           
			int studentID = Integer.parseInt(txtStudentID.getText());
            int addressTypeID = Integer.parseInt(txtAddressTypeID.getText());
            String homeNumber = txtHomeNumber.getText();
            String streetNumber = txtStreetNumber.getText();
            int provinceID = Integer.parseInt(txtProvinceID.getText());
            int districtID = Integer.parseInt(txtDistrictID.getText());
            int communeID = Integer.parseInt(txtCommuneID.getText());
            int villageID = Integer.parseInt(txtVillageID.getText());

            try (Connection con = DriverManager.getConnection(URL, USER, PASSWORD);
                 PreparedStatement pst = con.prepareStatement("INSERT INTO TblAddress (AddressID, StudentID, AddressTypeID, HomeNumber, StreetNumber, ProvinceID, DistrictID, CommuneID, VillageID) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)")) {
                
                pst.setInt(1, addressID);
                pst.setInt(2, studentID);
                pst.setInt(3, addressTypeID);
                pst.setString(4, homeNumber);
                pst.setString(5, streetNumber);
                pst.setInt(6, provinceID);
                pst.setInt(7, districtID);
                pst.setInt(8, communeID);
                pst.setInt(9, villageID);
                
                pst.executeUpdate();
                JOptionPane.showMessageDialog(this, "Address Added Successfully!");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid input. Please enter valid data.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    


    private void loadFaculty() {
        textArea.setText(""); // Clear previous data
        try (Connection con = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM TblFaculty")) {
            
            while (rs.next()) {
                textArea.append(rs.getInt("FacultyID") + " - " + rs.getString("FacultyKH") + " - " + rs.getString("FacultyEN") + "\n");
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            new facultygui();
        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, "MySQL Driver not found!");
        }
    }
}