package GUI;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Addressgui extends JFrame {
    private JTextField txtAddressID, txtStudentID, txtAddressTypeID, txtHomeNumber, txtStreetNumber, txtProvinceID;
    private JTextField txtDistrictID, txtCommuneID, txtVillageID;
    private JButton btnAdd, btnUpdate, btnDelete, btnRefresh;
    private JTable table;
    private DefaultTableModel model;

    private static final String URL = "jdbc:mysql://localhost:3306/StudentDB";
    private static final String USER = "root";  // Change based on your setup
    private static final String PASSWORD = "";  // Change based on your setup

    public Addressgui() {
        setTitle("Address Management");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Top Panel for Input Fields
        JPanel panelTop = new JPanel(new GridLayout(10, 2, 10, 10));
        panelTop.setBorder(BorderFactory.createTitledBorder("Address Information"));

        panelTop.add(new JLabel("Address ID:"));
        txtAddressID = new JTextField();
        panelTop.add(txtAddressID);

        panelTop.add(new JLabel("Student ID:"));
        txtStudentID = new JTextField();
        panelTop.add(txtStudentID);

        panelTop.add(new JLabel("Address Type ID:"));
        txtAddressTypeID = new JTextField();
        panelTop.add(txtAddressTypeID);

        panelTop.add(new JLabel("Home Number:"));
        txtHomeNumber = new JTextField();
        panelTop.add(txtHomeNumber);

        panelTop.add(new JLabel("Street Number:"));
        txtStreetNumber = new JTextField();
        panelTop.add(txtStreetNumber);

        panelTop.add(new JLabel("Province ID:"));
        txtProvinceID = new JTextField();
        panelTop.add(txtProvinceID);

        panelTop.add(new JLabel("District ID:"));
        txtDistrictID = new JTextField();
        panelTop.add(txtDistrictID);

        panelTop.add(new JLabel("Commune ID:"));
        txtCommuneID = new JTextField();
        panelTop.add(txtCommuneID);

        panelTop.add(new JLabel("Village ID:"));
        txtVillageID = new JTextField();
        panelTop.add(txtVillageID);

        add(panelTop, BorderLayout.NORTH);

        // Center Panel for Table
        model = new DefaultTableModel(new String[]{"Address ID", "Student ID", "Address Type ID", "Home Number", "Street Number", "Province ID", "District ID", "Commune ID", "Village ID"}, 0);
        table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // Bottom Panel for Buttons
        JPanel panelBottom = new JPanel();
        btnAdd = new JButton("Add");
        btnUpdate = new JButton("Update");
        btnDelete = new JButton("Delete");
        btnRefresh = new JButton("Refresh");

        panelBottom.add(btnAdd);
        panelBottom.add(btnUpdate);
        panelBottom.add(btnDelete);
        panelBottom.add(btnRefresh);

        add(panelBottom, BorderLayout.SOUTH);

        // Load Data
        loadData();

        // Button Listeners
        btnAdd.addActionListener(e -> insertData());
        btnUpdate.addActionListener(e -> updateData());
        btnDelete.addActionListener(e -> deleteData());
        btnRefresh.addActionListener(e -> loadData());

        // Table Row Selection Listener
        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int row = table.getSelectedRow();
                txtAddressID.setText(model.getValueAt(row, 0).toString());
                txtStudentID.setText(model.getValueAt(row, 1).toString());
                txtAddressTypeID.setText(model.getValueAt(row, 2).toString());
                txtHomeNumber.setText(model.getValueAt(row, 3).toString());
                txtStreetNumber.setText(model.getValueAt(row, 4).toString());
                txtProvinceID.setText(model.getValueAt(row, 5).toString());
                txtDistrictID.setText(model.getValueAt(row, 6).toString());
                txtCommuneID.setText(model.getValueAt(row, 7).toString());
                txtVillageID.setText(model.getValueAt(row, 8).toString());
            }
        });

        setVisible(true);
    }

    // Load Data from MySQL
    private void loadData() {
        model.setRowCount(0);
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM TblAddress")) {
            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("AddressID"),
                        rs.getInt("StudentID"),
                        rs.getInt("AddressTypeID"),
                        rs.getString("HomeNumber"),
                        rs.getString("StreetNumber"),
                        rs.getInt("ProvinceID"),
                        rs.getInt("DistrictID"),
                        rs.getInt("CommuneID"),
                        rs.getInt("VillageID")
                });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Insert Data
    private void insertData() {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pst = conn.prepareStatement("INSERT INTO TblAddress VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)")) {
            pst.setInt(1, Integer.parseInt(txtAddressID.getText()));
            pst.setInt(2, Integer.parseInt(txtStudentID.getText()));
            pst.setInt(3, Integer.parseInt(txtAddressTypeID.getText()));
            pst.setString(4, txtHomeNumber.getText());
            pst.setString(5, txtStreetNumber.getText());
            pst.setInt(6, Integer.parseInt(txtProvinceID.getText()));
            pst.setInt(7, Integer.parseInt(txtDistrictID.getText()));
            pst.setInt(8, Integer.parseInt(txtCommuneID.getText()));
            pst.setInt(9, Integer.parseInt(txtVillageID.getText()));
            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "Address Added!");
            loadData();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Update Data
    private void updateData() {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pst = conn.prepareStatement("UPDATE TblAddress SET StudentID=?, AddressTypeID=?, HomeNumber=?, StreetNumber=?, ProvinceID=?, DistrictID=?, CommuneID=?, VillageID=? WHERE AddressID=?")) {
            pst.setInt(1, Integer.parseInt(txtStudentID.getText()));
            pst.setInt(2, Integer.parseInt(txtAddressTypeID.getText()));
            pst.setString(3, txtHomeNumber.getText());
            pst.setString(4, txtStreetNumber.getText());
            pst.setInt(5, Integer.parseInt(txtProvinceID.getText()));
            pst.setInt(6, Integer.parseInt(txtDistrictID.getText()));
            pst.setInt(7, Integer.parseInt(txtCommuneID.getText()));
            pst.setInt(8, Integer.parseInt(txtVillageID.getText()));
            pst.setInt(9, Integer.parseInt(txtAddressID.getText()));
            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "Address Updated!");
            loadData();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Delete Data
    private void deleteData() {
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete?", "Delete", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
                 PreparedStatement pst = conn.prepareStatement("DELETE FROM TblAddress WHERE AddressID=?")) {
                pst.setInt(1, Integer.parseInt(txtAddressID.getText()));
                pst.executeUpdate();
                JOptionPane.showMessageDialog(this, "Address Deleted!");
                loadData();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Addressgui::new);
    }
}
